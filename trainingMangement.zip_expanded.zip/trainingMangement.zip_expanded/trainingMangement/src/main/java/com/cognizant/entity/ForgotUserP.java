package com.cognizant.entity;

public class ForgotUserP {

}
