package com.cognizant.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Course {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long courseId;
	private String userId;
	private String courseName;
	private String courseDetail;
	private String competencyLevel;
	private String intendedAudience;
	private String prerequisites;
	private int duration;
	public long getCourseId() {
		return courseId;
	}
	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCourseDetail() {
		return courseDetail;
	}
	public void setCourseDetail(String courseDetail) {
		this.courseDetail = courseDetail;
	}
	public String getCompetencyLevel() {
		return competencyLevel;
	}
	public void setCompetencyLevel(String competencyLevel) {
		this.competencyLevel = competencyLevel;
	}
	public String getIntendedAudience() {
		return intendedAudience;
	}
	public void setIntendedAudience(String intendedAudience) {
		this.intendedAudience = intendedAudience;
	}
	public String getPrerequisites() {
		return prerequisites;
	}
	public void setPrerequisites(String prerequisites) {
		this.prerequisites = prerequisites;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Course(long courseId, String userId, String courseName, String courseDetail, String competencyLevel,
			String intendedAudience, String prerequisites, int duration) {
		super();
		this.courseId = courseId;
		this.userId = userId;
		this.courseName = courseName;
		this.courseDetail = courseDetail;
		this.competencyLevel = competencyLevel;
		this.intendedAudience = intendedAudience;
		this.prerequisites = prerequisites;
		this.duration = duration;
	}
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", userId=" + userId + ", courseName=" + courseName + ", courseDetail="
				+ courseDetail + ", competencyLevel=" + competencyLevel + ", intendedAudience=" + intendedAudience
				+ ", prerequisites=" + prerequisites + ", duration=" + duration + "]";
	}
	
	

}